In this project 1A, we made a database with movies, actors, directors, sales, etc. 

Some interesting things we incorporated for our data integrity is to make sure that 
the people’s date of death came after the date of birth, unless they are still alive, 
in which case the date of death value will be a null value. 

This is a very interesting project, which I can find a lot of real life uses for. 