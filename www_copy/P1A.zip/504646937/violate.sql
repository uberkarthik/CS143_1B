INSERT INTO Director(id, first, last, dob, dod) VALUES (68623, "Udayan", "Sahai", 12121997, 12122100);
/* 
ERROR 1062 (23000): Duplicate entry '68623' for key 'PRIMARY'

In the following statement we have tried to insert a primary key into the directors table that already exists. Since primary keys are unique and 
the one that we are trying to insert already exists. We get an error and out tuple does not get inserted. 
*/

INSERT INTO Actor(id, first, last, sex, dob, dod) VALUES (68635, "Udayan", "Sahai","Male", 12121997, 12122100);
/* 
ERROR 1062 (23000): Duplicate entry '68635' for key 'PRIMARY'

In the following statement we have tried to insert a primary key into the Actors table. Since the mentioned id already exists and since primary keys are unique. 
the one that we are trying to insert already exists. We get an error and out tuple does not get inserted. 
*/

INSERT INTO Movie(id, title, year, rating, company) VALUES (4734,"Udayan's Dream", 1997, "Amazing", "Udayan Productions"); 
/* 
ERROR 1062 (23000): Duplicate entry '4734' for key 'PRIMARY'
In the following statement we have tried to insert a primary key into the Movie table. Since the mentioned id already exists and since primary keys are unique. 
the one that we are trying to insert already exists. We get an error and out tuple does not get inserted. 
*/



INSERT INTO Sales(mid, ticketsSold, totalIncome) VALUES (4731, 3500, 3500); 
/* 
ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`CS143`.`Sales`, CONSTRAINT `Sales_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

In he follwing query we are trying to add 4731 as a mid entry into the sales table. However the mid column in the sales table is a foreign key the references 
the movies table, and since the mid that we are tying to insert doesnt actually exist we get an error as this would ccause corruption in the database.
*/ 

INSERT INTO MovieDirector(mid, did) VALUES (4731,375); 
/*
ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`CS143`.`MovieDirector`, CONSTRAINT `MovieDirector_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

In he follwing query we are trying to add 4731 as a mid entry into the movie director table. However the mid column in the sales table is a foreign key the references 
the movies table, and since the mid that we are tying to insert doesnt actually exist we get an error as this would ccause corruption in the database. 
*/ 


INSERT INTO MovieGenre(mid, genre) VALUES (4731,375); 
/*
ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`CS143`.`MovieGenre`, CONSTRAINT `MovieGenre_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

In he follwing query we are trying to add 4731 as a mid entry into the MovieGenre table. However the mid column in the sales table is a foreign key the references 
the movies table, and since the mid that we are tying to insert doesnt actually exist we get an error as this would ccause corruption in the database. 
*/


INSERT INTO MovieActor(mid, aid, role) VALUES (4731,375,375);
/*
ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`CS143`.`MovieActor`, CONSTRAINT `MovieActor_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

In he follwing query we are trying to add 4731 as a mid entry into the MovieActor table. However the mid column in the sales table is a foreign key the references 
the movies table, and since the mid that we are tying to insert doesnt actually exist we get an error as this would ccause corruption in the database. 
*/

INSERT INTO MovieRating(mid, imdb, rot) VALUES (56,55,55);
/*
ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`CS143`.`MovieRating`, CONSTRAINT `MovieRating_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

In he follwing query we are trying to add 56 as a mid entry into the MovieRating table. However the mid column in the sales table is a foreign key the references 
the movies table, and since the mid that we are tying to insert doesnt actually exist we get an error as this would ccause corruption in the database. 
*/

INSERT INTO Review(name, time, mid, rating, comment) VALUES ("UDAYAN",'1970-01-01 00:00:01',56,55,"shit"); 
/*
ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`CS143`.`Review`, CONSTRAINT `Review_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

In he follwing query we are trying to add 56 as a mid entry into the Review table. However the mid column in the sales table is a foreign key the references 
the movies table, and since the mid that we are tying to insert doesnt actually exist we get an error as this would ccause corruption in the database. 
*/


/* 
No error messages for check as check inst supported in MySQL

*/ 

INSERT INTO Actor(id, first, last, sex, dob, dod) VALUES (68634, "Udayan", "Sahai","Male", 19971212, 19961212);
/* 
In the follwing query we are trying to create a tuple where the date of death is after the date of birth. Since this is not permissible to due a check condition. 
THe following query qould violate our constraint. 
*/ 

INSERT INTO Sales(mid, ticketsSold, totalIncome) VALUES (56,-5,5); 
/* In the follwing query we are trying to enter insert a tuple that contains a negative value for the tickets sold. Since thei is not allowed by our checkj statement 
this woud be a violatioin of our constraint. 
*/ 

INSERT INTO Director(id, last, first, dob, dod) VALUES(56,"sahai", "Udayan", 19971212, 19961212); 
/* 
In the follwing query we are trying to create a tuple where the date of death is after the date of birth. Since this is not permissible to due a check condition. 
THe following query qould violate our constraint. 
*/
